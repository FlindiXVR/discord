<?php

namespace IPS\discord\Exceptions;

use Exception as BaseException;

class DiscordException extends BaseException {}
