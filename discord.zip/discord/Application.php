<?php

namespace IPS\discord;

use IPS\Application as SystemApplication;

require 'vendor/autoload.php';

class Application extends SystemApplication
{
    protected function get__icon(): string
    {
        return 'discord fa-brands';
    }

    public function acpMenuNumber(string $queryString): int
    {
        if ($queryString === 'app=discord&module=system&controller=requests') {
            return InviteRequest::countWhere();
        }

        return parent::acpMenuNumber($queryString);
    }
}
