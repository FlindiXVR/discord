<?php

namespace IPS\discord\widgets;

use ErrorException;
use Illuminate\Http\Client\ConnectionException;
use IPS\discord\Api\Guild;
use IPS\discord\Discord as BaseDiscord;
use IPS\Helpers\Form;
use IPS\Settings;
use IPS\Theme;
use IPS\Widget\StaticCache;
use Throwable;

use function defined;

if (! defined('\IPS\SUITE_UNIQUE_KEY')) {
    header(($_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0').' 403 Forbidden');
    exit;
}

class Discord extends StaticCache
{
    public string $key = 'Discord';

    public string $app = 'discord';

    public function configuration(?Form &$form = null): Form
    {
        $form = parent::configuration($form);

        $settings = json_decode(Settings::i()->discord_widget_settings ?? '', true) ?? [];

        $form->add(new Form\Select('discord_width_theme', data_get($settings, 'discord_width_theme', 'dark') ?? 'dark', true, [
            'options' => [
                'dark' => 'Dark',
                'light' => 'Light',
            ],
        ]));

        $form->add(new Form\Text('discord_width_height', data_get($settings, 'discord_width_height', '500') ?? '500'));
        $form->add(new Form\Text('discord_width_width', data_get($settings, 'discord_width_width', '350') ?? '350'));

        return $form;
    }

    public function preConfig(array $values): array
    {
        $settings = json_decode(Settings::i()->discord_widget_settings ?? '', true) ?? [];

        Settings::i()->changeValues([
            'discord_widget_settings' => json_encode(array_merge($settings, $values)),
        ]);

        return $values;
    }

    /**
     * @throws Throwable
     * @throws ErrorException
     * @throws ConnectionException
     */
    public function render(): string
    {
        if (! BaseDiscord::enabled()) {
            return '';
        }

        $guild = Guild::getGuild();

        if (blank($guild)) {
            return '';
        }

        $settings = json_decode(Settings::i()->discord_widget_settings ?? '', true) ?? [];

        $id = data_get($guild, 'id');
        $theme = data_get($settings, 'discord_width_theme', 'dark') ?? 'dark';

        return (string) Theme::i()->getTemplate('system', 'discord', 'front')->widget(
            url: "https://discord.com/widget?id=$id&theme=$theme",
            height: data_get($settings, 'discord_width_height', '500') ?? '500',
            width: data_get($settings, 'discord_width_width', '350') ?? '350'
        );
    }
}
